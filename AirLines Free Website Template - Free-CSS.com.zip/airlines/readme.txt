======================================================================

	  Website Template Name: Airlines
	  Website Template URI: http://www.templatemonster.com/free-templates/free-website-template-airlines.php
	  Version: 1
	  Author: TemplateMonster.com Team
	  Author URI: http://www.templatemonster.com/

======================================================================


   +++ Be sure to visit TemplateMonster.com for more website templates +++


   +++ License +++

   Airlines website template is 100% FREE!  We kindly ask you to
   leave the footer links intact. Thank you so much! :)

   

   +++ INSTALLATION & EDITING +++

   - Copy all the files from the 'site' directory to the appropriate (usually 'www' or 'public_html') directory on your hosting. That's it.
   - This template may be edited with any HTML editor. If you do not know where to get one, you may consider trying NotePad++. It can be downloaded at notepad-plus.sourceforge.net and it's free.



   +++ HOW TO PUT YOUR OWN LOGO+++

   You need to replace logo.png (it is located in site>images>logo.png) with your own .png file. 


   +++ IMPORTANT NOTICE +++

   TemplateMonster doesn't provide support services on free templates - including this one. We only provide support for the products that are being purchased from TemplateMonster.
   Our free templates are produced according to the latest web standards and we�ve been trying to make the process of working with them as easy as possible, so for people with minimum web develpment 
   experience it should be easy to work with them. 

   